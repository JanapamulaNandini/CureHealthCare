package Curehealthcare;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CallingmakeA_POMFB {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64 (4)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
		Makeappointment_pomFB p = PageFactory.initElements(driver, Makeappointment_pomFB.class);
		p.menu.click();
		p.loginbutton.click();
		p.username.sendKeys("John Doe");
		p.password.sendKeys("ThisIsNotAPassword");
		p.login.click();
		WebElement p1 = driver.findElement(By.id("combo_facility"));
		Select s = new Select(p1);
		s.selectByVisibleText("Seoul CURA Healthcare Center");
		p.apply.click();
		p.medicare.click();
		p.date.click();
		p.date.sendKeys("02/12/2023");
		p.comment.sendKeys("i want to book my appointment on this date");
		p.bookA.click();
		p.b2h.click();

	}

}
