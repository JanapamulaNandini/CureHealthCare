package Curehealthcare;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Makeappointment_pomFB {

	@FindBy(xpath = "//*[@id=\"menu-toggle\"]/i")WebElement menu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a")WebElement loginbutton;
	@FindBy(id = "txt-username")WebElement username;
	@FindBy(id = "txt-password")WebElement password;
	@FindBy(id = "btn-login")WebElement login;
	@FindBy(id = "combo_facility")WebElement facility;
	@FindBy(id = "chk_hospotal_readmission")WebElement apply;
	@FindBy(className = "radio-inline")WebElement medicare;
	@FindBy(id = "txt_visit_date")WebElement date;
	@FindBy(id = "txt_comment")WebElement comment;
	@FindBy(id = "btn-book-appointment")WebElement bookA;
	@FindBy(xpath = "//*[@id=\"summary\"]/div/div/div[7]/p/a")WebElement b2h;
	
}
