package Curehealthcare;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class Callingpom_Login {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64 (4)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
        Login_Pom_findby p = PageFactory.initElements(driver, Login_Pom_findby.class);
        p.menu.click();
        p.loginbutton.click();
        p.username.sendKeys("John Doe");
        p.password.sendKeys("ThisIsNotAPassword");
        p.login.click();
        
	}

}
