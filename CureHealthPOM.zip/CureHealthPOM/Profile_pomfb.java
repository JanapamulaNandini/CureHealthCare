package Curehealthcare;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Profile_pomfb {

	@FindBy(xpath = "//*[@id=\"menu-toggle\"]/i")WebElement menu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a")WebElement loginbutton;
	@FindBy(id = "txt-username")WebElement username;
	@FindBy(id = "txt-password")WebElement password;
	@FindBy(id = "btn-login")WebElement login;
	@FindBy(xpath = "//*[@id=\"menu-toggle\"]/i")WebElement sidemenu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[4]/a")WebElement profile;
	@FindBy(xpath = "//*[@id=\"profile\"]/div/div/div/p[2]/a")WebElement Logout;
}
