package Curehealthcare;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class CallingPom_logout {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64 (4)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
        Logout_pomfb p = PageFactory.initElements(driver, Logout_pomfb.class);
        p.menu.click();
        p.loginbutton.click();
        p.username.sendKeys("John Doe");
        p.password.sendKeys("ThisIsNotAPassword");
        p.login.click();
        p.sidemenu.click();
        p.Logout.click();
	}

}
