package testNG_curehealthcare;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ProfileCure_TestNG {

	WebDriver driver;

	@BeforeTest
	public void launchapp() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64 (4)\\chromedriver-win64\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
	}

	@Test
	public void ProfileC() {
		driver.findElement(By.xpath("//*[@id=\"menu-toggle\"]/i")).click();
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a")).click();
		driver.findElement(By.id("txt-username")).sendKeys("John Doe");
		driver.findElement(By.id("txt-password")).sendKeys("ThisIsNotAPassword");
		driver.findElement(By.id("btn-login")).click();
		driver.findElement(By.xpath("//*[@id=\"menu-toggle\"]/i")).click();
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[4]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"profile\"]/div/div/div/p[2]/a")).click();
	}

	@AfterTest
	public void closeapp() {
		driver.close();
	}

}
