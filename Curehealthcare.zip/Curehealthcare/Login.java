package Curehealthcare;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class Login {

	public static void main(String[] args) throws Exception {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64 (4)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
		//menu
		driver.findElement(By.xpath("//*[@id=\"menu-toggle\"]/i")).click();
	    //click login button
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a")).click();
		//username
		driver.findElement(By.id("txt-username")).sendKeys("John Doe");
		//password
		driver.findElement(By.id("txt-password")).sendKeys("ThisIsNotAPassword");
		//login
		driver.findElement(By.id("btn-login")).click();
		driver.close();	
	}	
}
