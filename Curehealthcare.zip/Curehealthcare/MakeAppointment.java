package Curehealthcare;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MakeAppointment {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64 (4)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();

		//menu
		driver.findElement(By.xpath("//*[@id=\"menu-toggle\"]/i")).click();
	    //click login button
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a")).click();
		//username
		driver.findElement(By.id("txt-username")).sendKeys("John Doe");
		//password
		driver.findElement(By.id("txt-password")).sendKeys("ThisIsNotAPassword");
		//login
		driver.findElement(By.id("btn-login")).click();
		//facility
		WebElement fdd = driver.findElement(By.id("combo_facility"));
		Select s = new Select(fdd);
		s.selectByVisibleText("Seoul CURA Healthcare Center");
		//click apply
		driver.findElement(By.id("chk_hospotal_readmission")).click();
		//click medicare
		driver.findElement(By.className("radio-inline")).click();
		//date
		WebElement date = driver.findElement(By.id("txt_visit_date"));
		date.click();
		date.sendKeys("02/12/2023");
		//comment
		driver.findElement(By.id("txt_comment")).sendKeys("i want to book my appointment on this date");
		//click bookappointment
		driver.findElement(By.id("btn-book-appointment")).click();
		//click backtohome
		driver.findElement(By.xpath("//*[@id=\"summary\"]/div/div/div[7]/p/a")).click();
		
		
	}
}
