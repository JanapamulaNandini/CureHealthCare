package Curehealthcare;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Profile {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Nandu\\Downloads\\chromedriver-win64 (4)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
		// menu
		driver.findElement(By.xpath("//*[@id=\"menu-toggle\"]/i")).click();
		// click login button
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a")).click();
		// username
		driver.findElement(By.id("txt-username")).sendKeys("John Doe");
		// password
		driver.findElement(By.id("txt-password")).sendKeys("ThisIsNotAPassword");
		// click login
		driver.findElement(By.id("btn-login")).click();
		// sidemenubar
		driver.findElement(By.xpath("//*[@id=\"menu-toggle\"]/i")).click();
		//click profile
		driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[4]/a")).click();
        //click logout
		driver.findElement(By.xpath("//*[@id=\"profile\"]/div/div/div/p[2]/a")).click();
		driver.close();
	}
}
